"""Top-level package for Hypergraph Partitioning Challenge."""

__author__ = """Challenge Authors"""
__email__ = "filip.igor.pawlowski@huawei.com"
__version__ = "0.1.0"
